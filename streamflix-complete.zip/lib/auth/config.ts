// Mock auth config for demo
export const authOptions = {
  providers: [],
  callbacks: {},
}